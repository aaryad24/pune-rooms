import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import RoomCard from "@/components/room-card";
import { Pencil, LogOut } from "lucide-react";
import type { User, Room } from "@shared/schema";

// Update the mock current user data
const currentUser: User = {
  id: 1,
  username: "john_doe",
  fullName: "John Doe",
  email: "john@example.com",
  password: "",
  college: "MIT Pune",
  aboutYourself: "Computer Science student looking for accommodation near campus",
  profilePicture: "https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a",
};

export default function Profile() {
  const { data: userRooms } = useQuery<Room[]>({
    queryKey: [`/api/rooms/owner/${currentUser.id}`],
  });

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Profile Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-6"
      >
        <img
          src={currentUser.profilePicture || "https://via.placeholder.com/100"}
          alt={currentUser.fullName}
          className="w-24 h-24 rounded-full object-cover"
        />
        <div className="flex-1">
          <h1 className="text-3xl font-bold">{currentUser.fullName}</h1>
          <p className="text-muted-foreground">{currentUser.college}</p>
        </div>
        <div className="flex gap-4">
          <Button variant="outline" className="gap-2">
            <Pencil size={20} />
            Edit Profile
          </Button>
          <Button variant="destructive" className="gap-2">
            <LogOut size={20} />
            Logout
          </Button>
        </div>
      </motion.div>

      {/* Profile Content */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Tabs defaultValue="about">
          <TabsList>
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="listings">My Listings</TabsTrigger>
          </TabsList>

          {/* Update the About section in the TabsContent */}
          <TabsContent value="about">
            <Card>
              <CardContent className="pt-6 space-y-6">
                <div>
                  <h3 className="font-semibold mb-2">About myself</h3>
                  <p className="text-muted-foreground">{currentUser.aboutYourself}</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Contact Information</h3>
                  <p className="text-muted-foreground">{currentUser.email}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="listings">
            <div className="grid md:grid-cols-2 gap-6">
              {userRooms?.map((room, index) => (
                <motion.div
                  key={room.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <RoomCard room={room} />
                </motion.div>
              ))}
              {(!userRooms || userRooms.length === 0) && (
                <p className="text-muted-foreground col-span-2 text-center py-8">
                  You haven't listed any rooms yet
                </p>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}