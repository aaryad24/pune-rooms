import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Search, MessageSquare, UserPlus } from "lucide-react";

export default function Home() {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center space-y-6">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-6xl font-bold"
        >
          Find Your Perfect Room in Pune
        </motion.h1>
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-xl text-muted-foreground max-w-2xl mx-auto"
        >
          Connect with fellow students and find the ideal accommodation for your studies
        </motion.p>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Link href="/listings">
            <Button size="lg" className="gap-2">
              Browse Rooms <ArrowRight size={20} />
            </Button>
          </Link>
        </motion.div>
      </section>

      {/* Features */}
      <section className="grid md:grid-cols-3 gap-8">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card>
            <CardContent className="pt-6 text-center space-y-4">
              <Search size={40} className="mx-auto text-primary" />
              <h3 className="text-xl font-semibold">Easy Search</h3>
              <p className="text-muted-foreground">
                Find rooms that match your preferences with our powerful search filters
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardContent className="pt-6 text-center space-y-4">
              <MessageSquare size={40} className="mx-auto text-primary" />
              <h3 className="text-xl font-semibold">Direct Messaging</h3>
              <p className="text-muted-foreground">
                Connect directly with room owners through our messaging system
              </p>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardContent className="pt-6 text-center space-y-4">
              <UserPlus size={40} className="mx-auto text-primary" />
              <h3 className="text-xl font-semibold">Student Community</h3>
              <p className="text-muted-foreground">
                Join a community of students looking for the perfect accommodation
              </p>
            </CardContent>
          </Card>
        </motion.div>
      </section>

      {/* Featured Locations */}
      <section className="space-y-8">
        <h2 className="text-3xl font-bold text-center">Popular Areas in Pune</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              name: "City Center",
              image: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df",
            },
            {
              name: "Koregaon Park",
              image: "https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b",
            },
            {
              name: "Baner",
              image: "https://images.unsplash.com/photo-1449824913935-59a10b8d2000",
            },
            {
              name: "Viman Nagar",
              image: "https://images.unsplash.com/photo-1496568816309-51d7c20e3b21",
            },
          ].map((location, index) => (
            <motion.div
              key={location.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 * index }}
              className="relative overflow-hidden rounded-lg aspect-[4/3] group cursor-pointer"
            >
              <img
                src={location.image}
                alt={location.name}
                className="object-cover w-full h-full transition-transform group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <h3 className="text-white text-2xl font-bold">{location.name}</h3>
              </div>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
