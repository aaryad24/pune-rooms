import { motion } from "framer-motion";
import RoommateFinder from "@/components/roommate-finder";

export default function RoommatePage() {
  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold mb-2">Find Your Perfect Roommate</h1>
        <p className="text-muted-foreground">
          Connect with students looking for roommates or offering shared accommodations in Pune
        </p>
      </motion.div>

      <RoommateFinder />
    </div>
  );
}
