import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
} from "@/components/ui/navigation-menu";
import { Button } from "@/components/ui/button";
import { Home, Search, MessageSquare, User, Users } from "lucide-react";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-background">
      <nav className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <Link href="/">
                <a className="flex items-center">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className="text-2xl font-bold text-primary"
                  >
                    PuneRooms
                  </motion.div>
                </a>
              </Link>
            </div>

            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <Link href="/">
                    <NavigationMenuLink
                      className={`flex items-center gap-2 px-4 py-2 ${
                        location === "/" ? "text-primary" : ""
                      }`}
                    >
                      <Home size={20} />
                      Home
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/listings">
                    <NavigationMenuLink
                      className={`flex items-center gap-2 px-4 py-2 ${
                        location === "/listings" ? "text-primary" : ""
                      }`}
                    >
                      <Search size={20} />
                      Find Rooms
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/roommate-finder">
                    <NavigationMenuLink
                      className={`flex items-center gap-2 px-4 py-2 ${
                        location === "/roommate-finder" ? "text-primary" : ""
                      }`}
                    >
                      <Users size={20} />
                      Find Roommates
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/messages">
                    <NavigationMenuLink
                      className={`flex items-center gap-2 px-4 py-2 ${
                        location === "/messages" ? "text-primary" : ""
                      }`}
                    >
                      <MessageSquare size={20} />
                      Messages
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/profile">
                    <NavigationMenuLink
                      className={`flex items-center gap-2 px-4 py-2 ${
                        location === "/profile" ? "text-primary" : ""
                      }`}
                    >
                      <User size={20} />
                      Profile
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}